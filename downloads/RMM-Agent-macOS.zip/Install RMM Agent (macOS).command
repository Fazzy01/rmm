#!/bin/bash
# Double-click version of install-macos.sh - Finder runs .command files by
# opening Terminal and executing them, so this needs no chmod/curl typing
# from the user. Identical behavior to install-macos.sh otherwise; see that
# file for full comments. Keep the two in sync if you edit either.
#
# The first time this runs after being downloaded from the browser, macOS
# Gatekeeper will likely refuse to open it ("cannot be opened because it is
# from an unidentified developer") - that's the quarantine flag every
# downloaded script gets, same category as Windows SmartScreen on the
# unsigned .exe installer. Right-click the file -> Open -> Open once to
# clear it; there's no way to script past this without paying for an Apple
# Developer signing/notarization pipeline, which is out of scope here.

set -euo pipefail

SERVER_URL="${SERVER_URL:-ws://192.227.246.68:8000}"
TOKEN="${TOKEN:-}"
DOWNLOAD_BASE="${DOWNLOAD_BASE:-http://192.227.246.68:8000}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && pwd || true)"
AGENT_SRC_DIR="${SCRIPT_DIR:+$(dirname "$SCRIPT_DIR")}"
APP_DIR="$HOME/Library/Application Support/RmmAgent"
PLIST_PATH="$HOME/Library/LaunchAgents/com.rmm.agent.plist"
DEVICE_NAME="$(scutil --get ComputerName 2>/dev/null || hostname)"

echo "Installing RMM agent to: $APP_DIR"
mkdir -p "$APP_DIR"
if [ -n "$AGENT_SRC_DIR" ] && [ -f "$AGENT_SRC_DIR/agent.py" ]; then
    cp "$AGENT_SRC_DIR/agent.py" "$APP_DIR/agent.py"
    cp "$AGENT_SRC_DIR/requirements.txt" "$APP_DIR/requirements.txt"
else
    echo "No local checkout found - downloading agent.py from $DOWNLOAD_BASE ..."
    curl -fsSL "$DOWNLOAD_BASE/agent.py" -o "$APP_DIR/agent.py"
    curl -fsSL "$DOWNLOAD_BASE/requirements.txt" -o "$APP_DIR/requirements.txt"
fi

echo "Setting up Python virtual environment..."
python3 -m venv "$APP_DIR/venv"
"$APP_DIR/venv/bin/pip" install --quiet --upgrade pip
"$APP_DIR/venv/bin/pip" install --quiet -r "$APP_DIR/requirements.txt"

PYTHON_BIN="$APP_DIR/venv/bin/python3"

echo "Registering LaunchAgent (auto-start at login)..."
cat > "$PLIST_PATH" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.rmm.agent</string>
    <key>ProgramArguments</key>
    <array>
        <string>$PYTHON_BIN</string>
        <string>$APP_DIR/agent.py</string>
        <string>--server</string>
        <string>$SERVER_URL</string>
        <string>--device</string>
        <string>$DEVICE_NAME</string>
        <string>--token</string>
        <string>$TOKEN</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>$APP_DIR/agent.log</string>
    <key>StandardErrorPath</key>
    <string>$APP_DIR/agent.log</string>
</dict>
</plist>
PLIST

launchctl unload "$PLIST_PATH" >/dev/null 2>&1 || true
launchctl load -w "$PLIST_PATH"

echo ""
echo "Agent installed and started as device '$DEVICE_NAME' -> $SERVER_URL"
echo ""
echo "IMPORTANT - one-time manual step required by macOS:"
echo "  Two System Settings panes are about to open. In each, find and"
echo "  enable the entry for 'python3' (or add it with the + button if"
echo "  it isn't listed yet, pointing at: $PYTHON_BIN):"
echo "    - Screen Recording  (needed for the remote screen view)"
echo "    - Accessibility     (needed for remote mouse/keyboard control)"
echo ""
read -p "Press Enter to open those panes now..." _

open "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture"
sleep 1
open "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility"

echo ""
echo "After granting both, restart the agent so the grants take effect:"
echo "  launchctl kickstart -k gui/\$(id -u)/com.rmm.agent"
echo ""
read -p "Done. Press Enter to close this window..." _
