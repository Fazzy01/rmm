#!/bin/bash
# Double-click version of uninstall-macos.sh.
set -euo pipefail

PLIST_PATH="$HOME/Library/LaunchAgents/com.rmm.agent.plist"
APP_DIR="$HOME/Library/Application Support/RmmAgent"

launchctl bootout "gui/$(id -u)/com.rmm.agent" >/dev/null 2>&1 || true
launchctl unload "$PLIST_PATH" >/dev/null 2>&1 || true
rm -f "$PLIST_PATH"
rm -rf "$APP_DIR"

echo "RMM agent stopped and removed."
echo "Note: Screen Recording / Accessibility grants for python3 are left"
echo "in place in System Settings - remove them by hand there if you want."
echo ""
read -p "Press Enter to close this window..." _
